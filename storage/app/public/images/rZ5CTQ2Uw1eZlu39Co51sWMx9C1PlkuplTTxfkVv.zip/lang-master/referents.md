# Referents by language

| Lang | Assignee |
| --- |:--|
| ar | |
| az | |
| be | |
| bg | |
| bn | |
| bs | |
| ca | |
| cs | |
| cy | |
| da | [@jensstigaard](https://github.com/jensstigaard)  |
| de | [@WhereIsLucas](https://github.com/WhereIsLucas) |
| de_CH | |
| el | |
| es | |
| et | |
| eu | |
| fa | |
| fi | |
| fil | |
| fr | [@caouecs](https://github.com/caouecs), [@WhereIsLucas](https://github.com/WhereIsLucas) |
| gl | |
| he | |
| hi | |
| hr | |
| hu | |
| hy | |
| id | |
| is | |
| it | |
| ja | |
| ka | |
| kk | |
| km | |
| kn | |
| ko | |
| lt | |
| lv | |
| me | |
| mk | |
| mn | |
| mr | |
| ms | |
| nb | |
| ne | |
| nl | [@WhereIsLucas](https://github.com/WhereIsLucas) |
| nn | |
| pl | |
| ps | |
| pt | [@jorgercosta](https://github.com/jorgercosta) |
| pt_BR | |
| ro | |
| ru | [@andrey-helldar](https://github.com/andrey-helldar) |
| sc | |
| si | |
| sk | |
| sl | |
| sq | |
| sr_Cyrillic | [@LukaLatkovic](https://github.com/LukaLatkovic) |
| sr_Latin | [@LukaLatkovic](https://github.com/LukaLatkovic) |
| sv | |
| sw | |
| tg | |
| th | |
| tk | |
| tl | |
| tr | |
| ug | |
| uk | [@MrAlKuz](https://github.com/MrAlKuz) |
| ur | |
| uz_Cyrillic | |
| uz_Latin | |
| vi | |
| zh_CN | [@overtrue](https://github.com/overtrue) |
| zh_HK | [@overtrue](https://github.com/overtrue) |
| zh_TW | [@overtrue](https://github.com/overtrue) |
