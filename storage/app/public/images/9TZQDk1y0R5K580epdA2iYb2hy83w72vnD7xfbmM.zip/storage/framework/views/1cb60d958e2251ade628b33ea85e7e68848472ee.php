<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('Home')); ?>">Главная Сайт</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.news.index')); ?>">Главная Админка</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.news.create')); ?>">Создать новость</a>
</li>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.test1')); ?>">Скачать изображение</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('admin.test2')); ?>">Скачать текст</a>
</li>



<?php /**PATH /home/vagrant/code/laravel.local/resources/views/admin/menu.blade.php ENDPATH**/ ?>